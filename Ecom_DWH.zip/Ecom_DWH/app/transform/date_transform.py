import pandas as pd


class DateTransformer:
    @staticmethod
    def generate_date_dim(start, end):
        dates = pd.date_range(start=start, end=end)

        df = pd.DataFrame({"full_date": dates})

        df["date_key"] = df["full_date"].dt.strftime("%Y%m%d").astype(int)
        df["day"] = df["full_date"].dt.day
        df["month"] = df["full_date"].dt.month
        df["quarter"] = df["full_date"].dt.quarter
        df["year"] = df["full_date"].dt.year
        df["week"] = df["full_date"].dt.isocalendar().week
        df["weekday"] = df["full_date"].dt.weekday
        df["month_name"] = df["full_date"].dt.strftime("%B")

        return df