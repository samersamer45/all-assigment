import pandas as pd


class SellerTransformer:
    @staticmethod
    def transform(df):
        df = df.rename(columns={
            "seller_id": "seller_id",
            "seller_zip_code_prefix": "seller_zip_code_prefix",
            "seller_city": "seller_city",
            "seller_state": "seller_state"
        })

        df = df.drop_duplicates(subset=["seller_id"])

        return df