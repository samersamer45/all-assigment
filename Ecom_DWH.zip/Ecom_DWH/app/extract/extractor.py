import pandas as pd


class Extractor:
    def __init__(self, engine):
        self.engine = engine

    def extract_table(self, table_name: str, schema: str = "raw"):
        query = f"SELECT * FROM {schema}.{table_name}"
        return pd.read_sql(query, self.engine)