from app.config.database import DatabaseConfig
from app.extract.extractor import Extractor
from app.transform.product_transform import ProductTransformer


def run():

    engine = DatabaseConfig.get_engine()
    extractor = Extractor(engine)

    # Extract
    df = extractor.extract_table("products")

    # Transform
    df = ProductTransformer.transform(df)

    print("PRODUCTS:", df.shape)

    # Load
    df.to_sql(
        "dim_product",
        engine,
        schema="ec_dwh",
        if_exists="append",
        index=False
    )

    print("dim_product loaded")


if __name__ == "__main__":
    run()