import pandas as pd
from sqlalchemy import text

from app.config.database import DatabaseConfig


class FactSalesPipeline:
    """
    Load fact_sales table
    """

    def __init__(self):
        self.engine = DatabaseConfig.get_postgres_engine()

    def extract(self):
        orders = pd.read_sql(
            text("""
                SELECT *
                FROM ec_dwh.orders
            """),
            self.engine
        )

        order_items = pd.read_sql(
            text("""
                SELECT *
                FROM ec_dwh.order_items
            """),
            self.engine
        )

        order_payments = pd.read_sql(
            text("""
                SELECT *
                FROM ec_dwh.order_payments
            """),
            self.engine
        )

        return orders, order_items, order_payments

    def transform(self, orders, order_items, order_payments):
        df = orders.merge(
            order_items,
            on="order_id",
            how="inner"
        )

        df = df.merge(
            order_payments,
            on="order_id",
            how="left"
        )

        fact_sales = df[
            [
                "order_id",
                "customer_id",
                "product_id",
                "seller_id",
                "order_purchase_timestamp",
                "payment_value"
            ]
        ].copy()

        fact_sales.rename(
            columns={
                "order_purchase_timestamp": "order_purchase_date"
            },
            inplace=True
        )

        return fact_sales

    def load(self, df):
        df.to_sql(
            name="fact_sales",
            con=self.engine,
            schema="ec_dwh",
            if_exists="replace",
            index=False
        )

    def run(self):
        print("🔥 FACT SALES PIPELINE STARTED")

        orders, order_items, order_payments = self.extract()

        print("ORDERS:", orders.shape)
        print("ORDER ITEMS:", order_items.shape)
        print("PAYMENTS:", order_payments.shape)

        fact_sales = self.transform(
            orders,
            order_items,
            order_payments
        )

        print("FACT SALES:", fact_sales.shape)

        self.load(fact_sales)

        print("✅ FACT SALES LOADED")


def run():
    pipeline = FactSalesPipeline()
    pipeline.run()


if __name__ == "__main__":
    run()