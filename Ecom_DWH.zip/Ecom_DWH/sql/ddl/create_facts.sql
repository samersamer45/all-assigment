-- =====================================================
-- FACT: SALES
-- Grain = One row per order item
-- =====================================================

CREATE TABLE ec_dwh.fact_sales (
    sales_key BIGSERIAL PRIMARY KEY,

    order_id VARCHAR(50) NOT NULL,

    customer_key BIGINT NOT NULL,
    product_key BIGINT NOT NULL,
    seller_key BIGINT NOT NULL,
    date_key INT NOT NULL,

    order_item_id INT,
    price NUMERIC(12,2),
    freight_value NUMERIC(12,2),
    total_amount NUMERIC(12,2),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_sales_customer
        FOREIGN KEY (customer_key)
        REFERENCES ec_dwh.dim_customer(customer_key),

    CONSTRAINT fk_sales_product
        FOREIGN KEY (product_key)
        REFERENCES ec_dwh.dim_product(product_key),

    CONSTRAINT fk_sales_seller
        FOREIGN KEY (seller_key)
        REFERENCES ec_dwh.dim_seller(seller_key),

    CONSTRAINT fk_sales_date
        FOREIGN KEY (date_key)
        REFERENCES ec_dwh.dim_date(date_key)
);


CREATE INDEX idx_fact_sales_order_id
ON ec_dwh.fact_sales(order_id);

CREATE INDEX idx_fact_sales_date_key
ON ec_dwh.fact_sales(date_key);



-- =====================================================
-- FACT: PAYMENTS
-- Grain = One payment per order
-- =====================================================

CREATE TABLE ec_dwh.fact_payments (
    payment_fact_key BIGSERIAL PRIMARY KEY,

    order_id VARCHAR(50) NOT NULL,

    customer_key BIGINT NOT NULL,
    payment_key BIGINT NOT NULL,
    date_key INT NOT NULL,

    payment_sequential INT,
    payment_installments INT,
    payment_value NUMERIC(12,2),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_payments_customer
        FOREIGN KEY (customer_key)
        REFERENCES ec_dwh.dim_customer(customer_key),

    CONSTRAINT fk_payments_method
        FOREIGN KEY (payment_key)
        REFERENCES ec_dwh.dim_payment_method(payment_key),

    CONSTRAINT fk_payments_date
        FOREIGN KEY (date_key)
        REFERENCES ec_dwh.dim_date(date_key)
);


CREATE INDEX idx_fact_payments_order_id
ON ec_dwh.fact_payments(order_id);



-- =====================================================
-- FACT: REVIEWS
-- Grain = One review per order
-- =====================================================

CREATE TABLE ec_dwh.fact_reviews (
    review_fact_key BIGSERIAL PRIMARY KEY,

    order_id VARCHAR(50) NOT NULL,

    customer_key BIGINT NOT NULL,
    date_key INT NOT NULL,

    review_score INT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_reviews_customer
        FOREIGN KEY (customer_key)
        REFERENCES ec_dwh.dim_customer(customer_key),

    CONSTRAINT fk_reviews_date
        FOREIGN KEY (date_key)
        REFERENCES ec_dwh.dim_date(date_key)
);


CREATE INDEX idx_fact_reviews_order_id
ON ec_dwh.fact_reviews(order_id);



-- =====================================================
-- FACT: DELIVERY
-- Grain = One order delivery event
-- =====================================================

CREATE TABLE ec_dwh.fact_delivery (
    delivery_fact_key BIGSERIAL PRIMARY KEY,

    order_id VARCHAR(50) NOT NULL,

    customer_key BIGINT NOT NULL,
    seller_key BIGINT NOT NULL,
    date_key INT NOT NULL,

    estimated_delivery_days INT,
    actual_delivery_days INT,
    delay_days INT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_delivery_customer
        FOREIGN KEY (customer_key)
        REFERENCES ec_dwh.dim_customer(customer_key),

    CONSTRAINT fk_delivery_seller
        FOREIGN KEY (seller_key)
        REFERENCES ec_dwh.dim_seller(seller_key),

    CONSTRAINT fk_delivery_date
        FOREIGN KEY (date_key)
        REFERENCES ec_dwh.dim_date(date_key)
);


CREATE INDEX idx_fact_delivery_order_id
ON ec_dwh.fact_delivery(order_id);