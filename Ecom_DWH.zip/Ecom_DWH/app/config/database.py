from sqlalchemy import create_engine
from app.config.settings import settings


class DatabaseConfig:

    @staticmethod
    def get_engine():
        if settings.POSTGRES_URL:
            return DatabaseConfig.get_postgres_engine()
        elif settings.SQLITE_URL:
            return DatabaseConfig.get_sqlite_engine()
        else:
            raise ValueError("No database URL provided")

    @staticmethod
    def get_sqlite_engine():
        if not settings.SQLITE_URL:
            raise ValueError("SQLITE_URL is missing in .env")
        return create_engine(settings.SQLITE_URL)

    @staticmethod
    def get_postgres_engine():
        if not settings.POSTGRES_URL:
            raise ValueError("POSTGRES_URL is missing in .env")
        return create_engine(settings.POSTGRES_URL)