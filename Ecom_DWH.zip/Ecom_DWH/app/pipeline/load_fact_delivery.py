import pandas as pd
from sqlalchemy import text

from app.config.database import DatabaseConfig


class FactDeliveryPipeline:
    """
    Load fact_delivery table
    """

    def __init__(self):
        self.engine = DatabaseConfig.get_postgres_engine()

    def extract(self):
        orders = pd.read_sql(
            text("""
                SELECT *
                FROM ec_dwh.orders
            """),
            self.engine
        )

        return orders

    def transform(self, orders):
        orders["order_purchase_timestamp"] = pd.to_datetime(
            orders["order_purchase_timestamp"]
        )

        orders["order_delivered_customer_date"] = pd.to_datetime(
            orders["order_delivered_customer_date"]
        )

        orders["delivery_days"] = (
            orders["order_delivered_customer_date"]
            - orders["order_purchase_timestamp"]
        ).dt.days

        fact_delivery = orders[
            [
                "order_id",
                "order_purchase_timestamp",
                "order_delivered_customer_date",
                "delivery_days"
            ]
        ].copy()

        fact_delivery.rename(
            columns={
                "order_purchase_timestamp": "purchase_date",
                "order_delivered_customer_date": "delivery_date"
            },
            inplace=True
        )

        return fact_delivery

    def load(self, df):
        df.to_sql(
            name="fact_delivery",
            con=self.engine,
            schema="ec_dwh",
            if_exists="replace",
            index=False
        )

    def run(self):
        print("🚚 FACT DELIVERY PIPELINE STARTED")

        orders = self.extract()

        print("ORDERS:", orders.shape)

        fact_delivery = self.transform(orders)

        print("FACT DELIVERY:", fact_delivery.shape)

        self.load(fact_delivery)

        print("✅ FACT DELIVERY LOADED")


def run():
    pipeline = FactDeliveryPipeline()
    pipeline.run()


if __name__ == "__main__":
    run()