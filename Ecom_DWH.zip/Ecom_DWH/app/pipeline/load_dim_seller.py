from sqlalchemy import text
import pandas as pd
from sqlalchemy import text
from app.config.database import DatabaseConfig
def run():
    print("🔥 DIM SELLER PIPELINE STARTED")

    engine = DatabaseConfig.get_engine()

    df = pd.read_sql("SELECT * FROM raw.sellers", engine)

    print(f"RAW SELLERS: {df.shape}")

    df = df.drop_duplicates(subset=["seller_id"])

    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE ec_dwh.dim_seller RESTART IDENTITY CASCADE"))

    df.to_sql(
        "dim_seller",
        engine,
        schema="ec_dwh",
        if_exists="append",
        index=False,
        method="multi",
        chunksize=1000
    )

    print(f"SELLERS LOADED: {df.shape}")
    print("✅ dim_seller completed successfully")


if __name__ == "__main__":
    run()
