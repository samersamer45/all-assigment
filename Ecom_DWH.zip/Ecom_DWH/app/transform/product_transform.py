import pandas as pd


class ProductTransformer:

    @staticmethod
    def transform(df: pd.DataFrame) -> pd.DataFrame:

        df = df.copy()

        # =========================
        # Keep only existing columns safely
        # =========================

        expected_columns = [
            "product_id",
            "product_category_name",
            "product_name_length",
            "product_description_length",
            "product_photos_qty",
            "product_weight_g",
            "product_length_cm",
            "product_height_cm",
            "product_width_cm"
        ]

        # Add missing columns with default values
        for col in expected_columns:
            if col not in df.columns:
                df[col] = 0

        # =========================
        # Clean
        # =========================

        df = df.drop_duplicates(subset=["product_id"])

        df = df.fillna({
            "product_category_name": "unknown"
        })

        # =========================
        # Select final structure
        # =========================

        df = df[expected_columns]

        return df