import pandas as pd


class PaymentTransformer:
    @staticmethod
    def transform(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        df = df.drop_duplicates(subset=["payment_type"])

        return df[["payment_type"]]