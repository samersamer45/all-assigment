import os
from dotenv import load_dotenv
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
load_dotenv(BASE_DIR / ".env")


class Settings:
    POSTGRES_URL = os.getenv("POSTGRES_URL")

    SQLITE_URL = os.getenv("SQLITE_URL") or (
        "sqlite:///" + os.path.join(
            BASE_DIR,
            os.getenv("SQLITE_PATH", "")
        )
    )


settings = Settings()