import pandas as pd
from app.config.database import DatabaseConfig


class LoadRawOrderItems:
    def __init__(self):
        self.sqlite_engine = DatabaseConfig.get_sqlite_engine()
        self.pg_engine = DatabaseConfig.get_postgres_engine()

    def run(self):
        print("📥 LOADING RAW ORDER ITEMS")

        df = pd.read_sql(
            "SELECT * FROM order_items",
            self.sqlite_engine
        )

        print("ORDER ITEMS:", df.shape)

        df.to_sql(
            name="order_items",
            con=self.pg_engine,
            schema="ec_dwh",
            if_exists="replace",
            index=False
        )

        print("✅ RAW ORDER ITEMS LOADED")


def run():
    loader = LoadRawOrderItems()
    loader.run()


if __name__ == "__main__":
    run()