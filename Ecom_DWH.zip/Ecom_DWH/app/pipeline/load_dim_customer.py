from app.config.database import DatabaseConfig
from app.extract.extractor import Extractor
from app.transform.customer_transform import CustomerTransformer


def run():

    engine = DatabaseConfig.get_engine()
    extractor = Extractor(engine)

    # =========================
    # Extract
    # =========================
    df = extractor.extract_table("customers")

    # =========================
    # Transform
    # =========================
    df = CustomerTransformer.transform(df)

    # =========================
    # Load (IMPORTANT: create table with SERIAL KEY)
    # =========================
    df.to_sql(
        "dim_customer",
        engine,
        schema="ec_dwh",
        if_exists="append",
        index=False
    )

    print("dim_customer loaded")


if __name__ == "__main__":
    run()