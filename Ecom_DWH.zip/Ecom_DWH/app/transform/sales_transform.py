import pandas as pd


class SalesTransformer:

    @staticmethod
    def transform(
        orders_df,
        order_items_df,
        customers_df,
        products_df,
        sellers_df
    ):

        # =========================
        # 1. Build dimension maps
        # =========================

        customer_map = dict(zip(
            customers_df["customer_id"],
            customers_df["customer_key"]
        ))

        product_map = dict(zip(
            products_df["product_id"],
            products_df["product_key"]
        ))

        seller_map = dict(zip(
            sellers_df["seller_id"],
            sellers_df["seller_key"]
        ))

        # =========================
        # 2. Join Orders + Items
        # =========================

        df = order_items_df.merge(
            orders_df,
            on="order_id",
            how="left"
        )

        # =========================
        # 3. Map surrogate keys
        # =========================

        df["customer_key"] = df["customer_id"].map(customer_map)
        df["product_key"] = df["product_id"].map(product_map)
        df["seller_key"] = df["seller_id"].map(seller_map)

        # =========================
        # 4. Business logic
        # =========================

        df["total_amount"] = df["price"] + df["freight_value"]

        # =========================
        # 5. Select final FACT structure
        # =========================

        fact_df = df[[
            "order_id",
            "order_item_id",
            "price",
            "freight_value",
            "total_amount",
            "customer_key",
            "product_key",
            "seller_key",
            "order_purchase_timestamp"
        ]]

        return fact_df