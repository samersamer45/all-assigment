import pandas as pd
from sqlalchemy import create_engine
from app.config.database import DatabaseConfig


def run():
    print("📥 LOADING RAW ORDERS")

    # SQLite source (Olist dataset)
    sqlite_engine = create_engine("sqlite:///data/olist.sqlite")

    # PostgreSQL target
    pg_engine = DatabaseConfig.get_engine()

    orders = pd.read_sql("SELECT * FROM orders", sqlite_engine)

    print(f"ORDERS: {orders.shape}")

    orders.to_sql(
        "orders",
        pg_engine,
        schema="ec_dwh",
        if_exists="replace",
        index=False
    )

    print("✅ RAW ORDERS LOADED")


if __name__ == "__main__":
    run()