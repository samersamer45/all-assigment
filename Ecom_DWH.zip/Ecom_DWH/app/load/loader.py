class Loader:
    def __init__(self, engine):
        self.engine = engine

    def load_dataframe(
        self,
        dataframe,
        table_name,
        schema
    ):
        dataframe.to_sql(
            name=table_name,
            con=self.engine,
            schema=schema,
            if_exists="append",
            index=False
        )