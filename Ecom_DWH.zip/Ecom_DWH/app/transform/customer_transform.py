import pandas as pd


class CustomerTransformer:

    @staticmethod
    def transform(df: pd.DataFrame) -> pd.DataFrame:

        # =========================
        # 1. تنظيف البيانات
        # =========================
        df = df.copy()

        df = df.drop_duplicates(subset=["customer_id"])

        df = df.fillna({
            "customer_city": "unknown",
            "customer_state": "unknown"
        })

        # =========================
        # 2. ترتيب الأعمدة (Business view)
        # =========================
        df = df[[
            "customer_id",
            "customer_unique_id",
            "customer_zip_code_prefix",
            "customer_city",
            "customer_state"
        ]]

        return df