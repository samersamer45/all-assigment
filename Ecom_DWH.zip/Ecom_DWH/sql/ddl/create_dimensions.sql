-- =====================================================
-- DIMENSION: CUSTOMER
-- =====================================================

CREATE TABLE ec_dwh.dim_customer (
    customer_key BIGSERIAL PRIMARY KEY,
    customer_id VARCHAR(50) NOT NULL UNIQUE,
    customer_unique_id VARCHAR(50),
    customer_city VARCHAR(100),
    customer_state VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dim_customer_customer_id
ON ec_dwh.dim_customer(customer_id);


-- =====================================================
-- DIMENSION: PRODUCT
-- =====================================================

CREATE TABLE ec_dwh.dim_product (
    product_key BIGSERIAL PRIMARY KEY,
    product_id VARCHAR(50) NOT NULL UNIQUE,
    product_category_name VARCHAR(255),
    product_name_length INT,
    product_description_length INT,
    product_photos_qty INT,
    product_weight_g NUMERIC(10,2),
    product_length_cm NUMERIC(10,2),
    product_height_cm NUMERIC(10,2),
    product_width_cm NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dim_product_product_id
ON ec_dwh.dim_product(product_id);


-- =====================================================
-- DIMENSION: SELLER
-- =====================================================

CREATE TABLE ec_dwh.dim_seller (
    seller_key BIGSERIAL PRIMARY KEY,
    seller_id VARCHAR(50) NOT NULL UNIQUE,
    seller_city VARCHAR(100),
    seller_state VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dim_seller_seller_id
ON ec_dwh.dim_seller(seller_id);


-- =====================================================
-- DIMENSION: PAYMENT METHOD
-- =====================================================

CREATE TABLE ec_dwh.dim_payment_method (
    payment_key BIGSERIAL PRIMARY KEY,
    payment_type VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dim_payment_method_type
ON ec_dwh.dim_payment_method(payment_type);


-- =====================================================
-- DIMENSION: DATE
-- =====================================================

CREATE TABLE ec_dwh.dim_date (
    date_key INT PRIMARY KEY,
    full_date DATE NOT NULL UNIQUE,
    day INT,
    month INT,
    quarter INT,
    year INT,
    week INT,
    weekday INT,
    month_name VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_dim_date_full_date
ON ec_dwh.dim_date(full_date);
